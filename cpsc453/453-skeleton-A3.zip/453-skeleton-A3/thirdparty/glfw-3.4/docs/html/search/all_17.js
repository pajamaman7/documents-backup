var searchData=
[
  ['querying_20for_20vulkan_20presentation_20support_0',['Querying for Vulkan presentation support',['../vulkan_guide.html#vulkan_present',1,'']]],
  ['querying_20for_20vulkan_20support_1',['Querying for Vulkan support',['../vulkan_guide.html#vulkan_support',1,'']]],
  ['querying_20required_20vulkan_20extensions_2',['Querying required Vulkan extensions',['../vulkan_guide.html#vulkan_ext',1,'']]],
  ['querying_20vulkan_20function_20pointers_3',['Querying Vulkan function pointers',['../vulkan_guide.html#vulkan_proc',1,'']]],
  ['quick_2emd_4',['quick.md',['../quick_8md.html',1,'']]]
];
